package Priaid.Diagnosis.Model;

/// <summary>
/// Possible selector statuses
/// </summary>
public enum SelectorStatus {
    Man,
    Woman,
    Boy,
    Girl
}
