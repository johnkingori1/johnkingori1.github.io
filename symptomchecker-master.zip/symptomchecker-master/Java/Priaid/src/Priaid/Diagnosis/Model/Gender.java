package Priaid.Diagnosis.Model;

/// <summary>
/// Person gender
/// </summary>
public enum Gender {
	Male,
    Female
}
