package Priaid.Diagnosis.Model;

public class HealthItem
{
	/// <summary>
    /// Item ID
    /// </summary>
    public int ID;
    
    /// <summary>
    /// Item name
    /// </summary>
    public String Name;
}
